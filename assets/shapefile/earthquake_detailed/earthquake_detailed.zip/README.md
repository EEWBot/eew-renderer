気象庁から[地震情報／細分区域](https://www.data.jma.go.jp/developer/gis.html)をダウンロードし、
zip内のファイルを名前を`earthquake_detailed.$EXTENSION`に置換して配置する。